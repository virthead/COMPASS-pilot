import threading

class StoppableThread(threading.Thread):
    """ Thread class with a stop() method. The thread itself has to check regularly for the stopped() condition """

    def __init__(self, target=None, name='StoppableThread'):
        threading.Thread.__init__(self, target=target, name=name)
        self._stop = threading.Event()

    def stop(self):
        self._stop.set()

    def stopped(self):
        return self._stop.isSet()
